document.addEventListener('DOMContentLoaded', async () => {
  const JSON_URL = 'https://benditanobleza.netlify.app//data/products.json';

  try {
    const resp = await fetch(JSON_URL);
    const productos = await resp.json();

    // Si estás en una subpágina de "almohadon apego", filtrá solo esa categoría
    const filename = location.pathname.split('/').pop().toLowerCase();
    let categoria = '';
    if (filename.includes('almohadon')) categoria = 'almohadon apego';
    // ...agregá otras categorías según nombre de archivo

    // Si querés mostrar todos, podés saltear el filtro.
    const modelos = categoria ? productos.filter(p => p.categoria === categoria) : productos;

    const container = document.querySelector('.modelos');
    container.innerHTML = '';

    modelos.forEach(m => {
      const div = document.createElement('div');
      div.className = 'modelo';
      div.innerHTML = `
        <div class="modelo-img">
          <img src="img/${m.img1}" alt="${m.nombre}">
        </div>
        <div class="modelo-info">
          <h3>${m.nombre}</h3>
          <p>${m.descripcion}</p>
          <p><strong>Precio:</strong> $${m.precio}</p>
          <button class="add-to-cart"
                  data-id="${m.id}"
                  data-name="${m.nombre}"
                  data-price="${m.precio}">
            Agregar al carrito
          </button>
        </div>
      `;
      container.appendChild(div);
    });

    // Inicializar el carrito si lo tenés en otro script
    if (window.initCart) initCart();

  } catch (err) {
    console.error('Error cargando productos:', err);
  }
});
