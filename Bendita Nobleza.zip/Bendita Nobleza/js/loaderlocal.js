// js/loader.js
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // 1) Carga el JSON local (mismo dominio, sin CORS)
    const resp = await fetch('data/products.json');
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const all = await resp.json();

    // 2) Mapeo página → categoría
    const catMap = {
      'almohadon_apego.html':   'almohadon apego',
      'almohadones.html':       'almohadones',
      'remera_religiosa.html':  'remeras',
      'taza_religiosa.html':    'tazas',
      'mate_religioso.html':    'mates',
      'stickers_religiosos.html':'stickers'
    };
    const filename  = location.pathname.split('/').pop().toLowerCase();
    const categoria = catMap[filename] || '';
    
    // 3) Filtra y pinta
    const modelos = all.filter(p => p.categoria.toLowerCase() === categoria);
    const container = document.querySelector('.container .modelos');
    container.innerHTML = '';
    modelos.forEach(m => {
      const div = document.createElement('div');
      div.className = 'modelo';
      div.innerHTML = `
        <div class="modelo-img">
          <img src="img/${m.img1}" alt="${m.nombre}">
        </div>
        <div class="modelo-info">
          <h3>${m.nombre}</h3>
          <p>${m.descripcion}</p>
          <p><strong>Precio:</strong> $${m.precio}</p>
          <button class="add-to-cart"
                  data-id="${m.id}"
                  data-name="${m.nombre}"
                  data-price="${m.precio}">
            Agregar al carrito
          </button>
        </div>
      `;
      container.appendChild(div);
    });

    // 4) Inicializa slideshow y carrito (en tu script.js)
    if (window.initSlideshows) initSlideshows();
    if (window.initCart)      initCart();

  } catch (err) {
    console.error('Error cargando JSON local:', err);
  }
});
