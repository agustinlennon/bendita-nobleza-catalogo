// js/loader.js
window.addEventListener('DOMContentLoaded', () => {
  // URL de Google Sheets publicada (pubhtml)
  const SHEET_URL = 'https://docs.google.com/spreadsheets/d/1EiJDqSofwPYvh2Ub3e_dnQ7R8S3Sw5wWpuFcgmCdnlE/edit?usp=drive_link';

 console.log('Tabletop URL:', SHEET_URL);

  Tabletop.init({
    key: SHEET_URL,
    simpleSheet: true,
    callback: data => {

           console.log('Tabletop data recibida:', data);

      // Mapeo de nombre de archivo a categoría
      const catMap = {
        'Almohadones.html':   'almohadones',
        'almohadon_apego.html':        'almohadon apego',
        'indumentaria.html':       'remeras',
        'Taza.html':         'tazas',
        'Mate.html':         'mates',
        'Stickers.html':    'stickers'
      };

      const filename  = location.pathname.split('/').pop();
      const categoria = catMap[filename] || '';
      const modelos   = data.filter(item => item.categoria === categoria);

      const container = document.querySelector('.modelos');
      container.innerHTML = ''; // limpia cualquier contenido previo

      modelos.forEach(m => {
        const div = document.createElement('div');
        div.className = 'modelo';
        div.innerHTML = `
          <img src="img/${m.img1}" alt="${m.nombre}">
          <h3>${m.nombre}</h3>
          <p>${m.descripcion}</p>
          <p><strong>Precio:</strong> $${m.precio}</p>
          <button class="add-to-cart" data-id="${m.id}" data-name="${m.nombre}" data-price="${m.precio}">
            Agregar al carrito
          </button>
        `;
        container.appendChild(div);
      });

      // Inicializar slideshow y carrito
      if (window.initSlideshows) initSlideshows();
      if (window.initCart)      initCart();
    },
    error: err => console.error('Tabletop error:', err)
  });
});


